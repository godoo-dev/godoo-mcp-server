# @godoo-dev/introspection

TypeScript introspection and code generation for Odoo models.

## Features

- **Runtime Introspection**: Query Odoo's `ir.model` and `ir.model.fields` to discover models and their schemas
- **Type Generation**: Automatically generate TypeScript interfaces from live Odoo metadata
- **Field Type Mapping**: Intelligent mapping of Odoo field types to TypeScript types
- **Caching**: Built-in caching to minimize RPC calls
- **CLI Tool**: Command-line tool for easy code generation

## Installation

```bash
pnpm add @godoo-dev/introspection @godoo-dev/client
```

**Prerequisites**: Node.js ≥ 22.18.0, an authorized Odoo18 instance.

## Portable runtime and formatters

Use the portable exports when the host supplies an authorized client capability:

```ts
import { type IntrospectionClient, Introspector } from '@godoo-dev/introspection/portable';
import { generateModelInterface } from '@godoo-dev/introspection/formatters';

export async function describeContacts(client: IntrospectionClient) {
  const introspector = new Introspector(client);
  return generateModelInterface(await introspector.getModelMetadata('res.partner'));
}
```

`IntrospectionClient` requires only `call` and `searchRead`. It accepts the native
bound client, direct client and structurally compatible clients. `/portable`
exports `Introspector`, `IntrospectionCache`, types and runtime field mapping;
`/formatters` exports pure string generators and type mappers. Both ship their own
declarations and exclude filesystem generators, CLI, Node builtins and transports.
Existing package-root generation and CLI APIs retain their Node behavior.

Maps, synchronous cache accessors, cached object identity and explicit model/full
invalidation retain their native behavior. Hosts own target authorization and must
invalidate metadata after schema changes. The package's README and declarations
are version-bound reference material; `@godoo-dev/client/reference` supplies a
progressive index and `@godoo-dev/client/effects` declares introspection/formatter
effects. Runtime introspection reads still require host declarations for the
effective server implementations. See the [portable contract](../client/README.md#portable-client).

## Quick Start

### Programmatic Usage

```typescript
import { createClient } from '@godoo-dev/client';
import { Introspector } from '@godoo-dev/introspection';

// Reads ODOO_URL, ODOO_DB, ODOO_USER, ODOO_PASSWORD from env
const client = await createClient();

// Create introspector
const introspector = new Introspector(client);

// Get all models
const models = await introspector.getModels();
console.log(models.map(m => m.model)); // ['res.partner', 'sale.order', ...]

// Get fields for a model
const fields = await introspector.getFields('res.partner');

// Get complete metadata
const metadata = await introspector.getModelMetadata('res.partner');
console.log(metadata.model.name);    // 'Contact'
console.log(metadata.fields.length); // 50+
```

### CLI Usage

```bash
# Basic generation
odoo-introspect generate \
  --url http://localhost:8069 \
  --db odoo_dev \
  --password admin \
  --output src/models

# With options
odoo-introspect generate \
  --url http://localhost:8069 \
  --db odoo_dev \
  --password admin \
  --output src/models \
  --modules sale,project \
  --include-transient

# Via environment variables
export ODOO_URL=http://localhost:8069
export ODOO_DB=odoo_dev
export ODOO_PASSWORD=admin

odoo-introspect generate --output src/models
```

## API

### `Introspector` Class

#### Constructor

```typescript
new Introspector(client: OdooClient)
```

#### Methods

##### `getModels(options?)`

Retrieve all available models.

```typescript
const models = await introspector.getModels({
  includeTransient: false,  // Include wizard models
  modules: ['sale'],        // Filter by modules
  bypassCache: false        // Force fresh query
});
```

Returns: `Promise<OdooModel[]>`

##### `getFields(modelName, options?)`

Retrieve all fields for a model.

```typescript
const fields = await introspector.getFields('res.partner');
```

Returns: `Promise<OdooField[]>`

##### `getModelMetadata(modelName, options?)`

Retrieve complete metadata (model + fields).

```typescript
const metadata = await introspector.getModelMetadata('res.partner');
```

Returns: `Promise<ModelMetadata>`

##### `clearCache()`

Clear all cached introspection data.

```typescript
introspector.clearCache();
```

##### `clearModelCache(modelName)`

Clear cached data for a specific model.

```typescript
introspector.clearModelCache('res.partner');
```

### `CodeGenerator` Class

Generate TypeScript interfaces from Odoo schemas.

```typescript
import { CodeGenerator } from '@godoo-dev/introspection';

const generator = new CodeGenerator(client);

const code = await generator.generate({
  outputDir: './src/models',
  includeTransient: false,
  modules: undefined,
  bypassCache: false
});
```

## Generated Code

The code generator produces TypeScript interfaces like:

```typescript
/**
 * Contact
 *
 * Odoo Model: res.partner
 */
export interface ResPartner {
  /**
   * Name
   * @required
   */
  name: string;

  /**
   * Email
   */
  email?: string;

  /**
   * Customer
   */
  customer: boolean;

  // ... more fields
}
```

## Type Mapping

Odoo field types are mapped to TypeScript as follows:

| Odoo Type | TypeScript Type |
|-----------|-----------------|
| `char`, `text`, `html` | `string` |
| `integer` | `number` |
| `float`, `monetary` | `number` |
| `boolean` | `boolean` |
| `date`, `datetime` | `string` (ISO 8601) |
| `many2one` | `number` |
| `one2many`, `many2many` | `number[]` |
| `selection` | `string` |
| `binary` | `string` |

## Caching

Introspection results are cached in memory to minimize RPC overhead. Cache is automatically managed:

- Models are cached after the first `getModels()` call
- Fields are cached per-model after each `getFields()` call
- Combined metadata is cached after `getModelMetadata()` calls

Use `bypassCache: true` to force a fresh query, or call `clearCache()` to reset all caches.

## Logging

This package uses the `debug` library for logging. Enable debug output:

```bash
# All godoo logging
DEBUG=godoo-* pnpm test

# Only introspection logging
DEBUG=odoo-introspection:* pnpm test

# Specific modules
DEBUG=odoo-introspection:introspection,odoo-introspection:codegen pnpm test
```

## Related Packages

- [@godoo-dev/client](../client) — RPC client
- [@godoo-dev/testcontainers](../testcontainers) — Docker/Odoo test harness

## Bugs & Support

[GitHub Issues](https://github.com/godoo-dev/godoo-ts/issues)

## License

LGPL-3.0 — see [LICENSE](./LICENSE)
